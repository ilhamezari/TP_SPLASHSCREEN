package com.example.splashscreen_tp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Home_P_Activity extends AppCompatActivity {
    TextView username;
    TextView password;
    ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Account Informations");
        setContentView(R.layout.activity_home);
        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        TextView usernameLabel = findViewById(R.id.usernameL);
        TextView passwordLabel = findViewById(R.id.passwordL);
        back=findViewById(R.id.backHome);
        Bundle b=getIntent().getExtras();
        if (b != null) {
            String usr = b.getString("username");
            String pswd = b.getString("password");
            usernameLabel.setText(getString(R.string.user_name) + ": " + usr);
            passwordLabel.setText(getString(R.string.password) + ": " + pswd);
        }
        back.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });

    }
}