package com.example.splashscreen_tp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class
MainActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    Button IDENTIFY;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Account");
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.usrname);
        password = findViewById(R.id.pswd);
        IDENTIFY = findViewById(R.id.login);

        IDENTIFY.setOnClickListener(view -> {
            String name = username.getText().toString();
            String pass = password.getText().toString();

            Intent intent = new Intent(this,Home_P_Activity.class);
            intent.putExtra("username", name);
            intent.putExtra("password", pass);
            startActivity(intent);
        });
    }
}
